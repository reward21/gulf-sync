# Quick Log — {{DATE}}

## What changed today
- 

## What I need from the system
- 

## Notes / context
- 
