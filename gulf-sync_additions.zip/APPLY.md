# Apply these files to your local repo

1) Download and unzip into your repo root:
   - Your repo root is: `~/Projects/gulf-sync`

2) From repo root, run:
   - `git status`  (you should see new files under canon/, sync/, inbox/)
   - `./gs agent run` (should still work)

Notes:
- These are additive starter files only. Nothing here modifies your existing python.
